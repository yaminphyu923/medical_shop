<footer class="footer">

    <div class="d-flex align-items-center justify-content-end">
        <div>Copyright ©2022.</div>
        <div>Developed by MMCities</div>
    </div>

</footer>
